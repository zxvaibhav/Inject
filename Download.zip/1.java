//
// Decompiled by Jadx - 1306ms
//
package com.google.android.gms;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.net.Uri;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.HomeActivity$;

public class HomeActivity {
    private static final String KEY_DONT_SHOW = "dontShowAgain";
    private static final String PREF_NAME = "VAIBHAVSATPUTE";
    static boolean darkMode = true;
    private static String titleText = "💥 OpModsForYou 💥";
    private static String titleUrl = "https://t.me/VAIBHAVSATPUTE_BOT";
    private static String siteName = "Telegram";
    private static String siteUrl = "https://graph.org/VAIBHAV-04-13";
    private static String gamesName = "Games";
    private static String gamesUrl = "https://t.me/UnofficialModsApk";
    private static String appsName = "Web";
    private static String appsUrl = "http://vaibhavsatputeprofile.blogspot.com/p/about-modder.html";
    private static String joinTgName = "Join TG";
    private static String privateName = "Channel";
    private static String privateUrl = "https://t.me/+4narFQS1C5kxYjBl";
    private static String liteApksName = "YouTube";
    private static String liteApksUrl = "https://youtube.com/@OpModsForYou";
    private static String backupName = "TG:-GC";
    private static String backupUrl = "https://t.me/+JUOnwAnSLwEwMzll";
    private static String telegramUrl = "https://t.me/OpModsForYou";
    private static String dialogText = "Exclusive Games And Apps Mods Only on " + siteName + "\n\nCheck Modded " + gamesName + " & " + appsName + "\n\n" + joinTgName + " " + privateName + "|" + liteApksName + "|" + backupName + "\n";

    public static void onCreate(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, 0);
        boolean dontShowAgain = prefs.getBoolean(KEY_DONT_SHOW, false);
        if (!dontShowAgain) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            AlertDialog create = builder.create();
            Activity activity = (Activity) context;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.gravity = 17;
            layoutParams.weight = 1.0f;
            layoutParams.setMargins(20, 20, 20, 20);
            LinearLayout linearLayout = new LinearLayout(context);
            linearLayout.setOrientation(1);
            linearLayout.setPadding(20, 50, 20, 50);
            linearLayout.setElevation(8.0f);
            linearLayout.setLayoutParams(layoutParams);
            GradientDrawable borderDrawable = new GradientDrawable();
            borderDrawable.setShape(0);
            borderDrawable.setCornerRadius(20.0f);
            borderDrawable.setStroke(15, -65536);
            borderDrawable.setColor(darkMode ? -16777216 : -1);
            linearLayout.setBackground(borderDrawable);
            startRGBAnimation(borderDrawable);
            TextView titleView = new TextView(context);
            SpannableString titleSpannable = new SpannableString(titleText);
            titleSpannable.setSpan(new HomeActivity$1(activity), 0, titleSpannable.length(), 33);
            titleSpannable.setSpan(new ForegroundColorSpan(Color.parseColor("#FF0000")), 0, titleSpannable.length(), 33);
            titleView.setText(titleSpannable);
            titleView.setMovementMethod(LinkMovementMethod.getInstance());
            titleView.setGravity(17);
            titleView.setLayoutParams(layoutParams);
            titleView.setPadding(0, 0, 0, 50);
            titleView.setTextSize(20.0f);
            titleView.setTypeface(titleView.getTypeface(), 1);
            TextView bodyView = new TextView(context);
            SpannableString spannableString = new SpannableString(dialogText);
            setClickableSpan(spannableString, siteName, siteUrl, activity, 0, "#FF00FF");
            setClickableSpan(spannableString, gamesName, gamesUrl, activity, dialogText.indexOf("Check Modded"), "#00FF00");
            setClickableSpan(spannableString, appsName, appsUrl, activity, dialogText.indexOf("Check Modded"), "#FFFF00");
            setClickableSpan(spannableString, privateName, privateUrl, activity, dialogText.indexOf(joinTgName), "#FFA500");
            setClickableSpan(spannableString, liteApksName, liteApksUrl, activity, dialogText.indexOf(joinTgName), "#00FFFF");
            setClickableSpan(spannableString, backupName, backupUrl, activity, dialogText.indexOf(joinTgName), "#800080");
            bodyView.setText(spannableString);
            bodyView.setMovementMethod(LinkMovementMethod.getInstance());
            bodyView.setGravity(17);
            bodyView.setLayoutParams(layoutParams);
            bodyView.setPadding(10, 0, 10, 10);
            bodyView.setTextSize(16.0f);
            bodyView.setTextColor(darkMode ? -1 : -16777216);
            LinearLayout linearLayout2 = new LinearLayout(context);
            linearLayout2.setOrientation(0);
            linearLayout2.setGravity(17);
            LinearLayout.LayoutParams checkBoxLayoutParams = new LinearLayout.LayoutParams(-1, -2);
            checkBoxLayoutParams.setMargins(20, 0, 20, 5);
            linearLayout2.setLayoutParams(checkBoxLayoutParams);
            CheckBox checkBox = new CheckBox(context);
            checkBox.setTextColor(darkMode ? -1 : -16777216);
            LinearLayout.LayoutParams checkBoxParams = new LinearLayout.LayoutParams(-2, -2);
            checkBoxParams.gravity = 16;
            checkBox.setLayoutParams(checkBoxParams);
            TextView checkBoxText = new TextView(context);
            checkBoxText.setText("Don't show again");
            checkBoxText.setTextSize(14.0f);
            checkBoxText.setTextColor(darkMode ? -1 : -16777216);
            LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-2, -2);
            textParams.gravity = 16;
            textParams.setMargins(8, 0, 0, 0);
            checkBoxText.setLayoutParams(textParams);
            linearLayout2.addView(checkBox);
            linearLayout2.addView(checkBoxText);
            LinearLayout buttonLayout = new LinearLayout(context);
            buttonLayout.setOrientation(0);
            buttonLayout.setPadding(15, 0, 15, 0);
            LinearLayout.LayoutParams buttonLayoutParams = new LinearLayout.LayoutParams(-1, -2);
            buttonLayoutParams.gravity = 17;
            buttonLayoutParams.weight = 1.0f;
            buttonLayoutParams.setMargins(20, 10, 20, 0);
            buttonLayout.setLayoutParams(buttonLayoutParams);
            buttonLayout.setBackgroundColor(darkMode ? -16777216 : -1);
            TextView closeButton = new TextView(context);
            closeButton.setText("Close");
            closeButton.setTextSize(15.0f);
            closeButton.setPadding(35, 7, 35, 7);
            closeButton.setGravity(17);
            closeButton.setTypeface(closeButton.getTypeface(), 1);
            closeButton.setTextColor(-1);
            closeButton.setBackground(getRoundedDrawable(15, Color.parseColor("#ff0092ff")));
            TextView joinButton = new TextView(context);
            joinButton.setText("Join Telegram");
            joinButton.setTextSize(15.0f);
            joinButton.setPadding(25, 7, 25, 7);
            joinButton.setGravity(17);
            joinButton.setTypeface(joinButton.getTypeface(), 1);
            joinButton.setTextColor(-1);
            joinButton.setBackground(getRoundedDrawable(15, Color.parseColor("#ff0092ff")));
            TextView spacer = new TextView(context);
            spacer.setLayoutParams(buttonLayoutParams);
            buttonLayout.addView(closeButton);
            buttonLayout.addView(spacer);
            buttonLayout.addView(joinButton);
            linearLayout.addView(titleView);
            linearLayout.addView(bodyView);
            linearLayout.addView(linearLayout2);
            linearLayout.addView(buttonLayout);
            create.setView(linearLayout);
            create.setCancelable(false);
            create.requestWindowFeature(1);
            create.getWindow().setSoftInputMode(32);
            create.getWindow().setBackgroundDrawableResource(0x0106000d);
            closeButton.setOnClickListener(new HomeActivity$.ExternalSyntheticLambda1(checkBox, prefs, create));
            joinButton.setOnClickListener(new HomeActivity$.ExternalSyntheticLambda2(checkBox, prefs, activity, create));
            create.show();
        }
    }

    static void lambda$onCreate$0(CheckBox dontShowCheckBox, SharedPreferences prefs, AlertDialog dialog, View v) {
        if (dontShowCheckBox.isChecked()) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean(KEY_DONT_SHOW, true);
            editor.apply();
        }
        dialog.dismiss();
    }

    static void lambda$onCreate$1(CheckBox dontShowCheckBox, SharedPreferences prefs, Activity activity, AlertDialog dialog, View v) {
        if (dontShowCheckBox.isChecked()) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean(KEY_DONT_SHOW, true);
            editor.apply();
        }
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(telegramUrl));
        activity.startActivity(intent);
        dialog.dismiss();
    }

    private static void setClickableSpan(SpannableString spannable, String word, String url, Activity activity, int startIndex, String color) {
        int start = spannable.toString().indexOf(word, startIndex);
        if (start != -1) {
            int end = word.length() + start;
            spannable.setSpan(new HomeActivity$2(url, activity), start, end, 33);
            spannable.setSpan(new ForegroundColorSpan(Color.parseColor(color)), start, end, 33);
        }
    }

    private static ShapeDrawable getRoundedDrawable(int radius, int color) {
        float[] radii = {radius, radius, radius, radius, radius, radius, radius, radius};
        ShapeDrawable drawable = new ShapeDrawable(new RoundRectShape(radii, null, null));
        drawable.getPaint().setColor(color);
        return drawable;
    }

    private static void startRGBAnimation(GradientDrawable drawable) {
        int[] colors = {-65536, -65281, -16776961, -16711681, -16711936, -256, -65536};
        ValueAnimator colorAnimator = ValueAnimator.ofInt(colors);
        colorAnimator.setEvaluator(new ArgbEvaluator());
        colorAnimator.setDuration(3000L);
        colorAnimator.setRepeatCount(-1);
        colorAnimator.setRepeatMode(1);
        colorAnimator.addUpdateListener(new HomeActivity$.ExternalSyntheticLambda0(drawable));
        colorAnimator.start();
    }

    static void lambda$startRGBAnimation$2(GradientDrawable drawable, ValueAnimator animator) {
        int animatedColor = ((Integer) animator.getAnimatedValue()).intValue();
        drawable.setStroke(15, animatedColor);
    }
}
